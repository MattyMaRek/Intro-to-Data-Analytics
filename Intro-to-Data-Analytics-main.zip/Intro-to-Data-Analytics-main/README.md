# Intro-to-Data-Analytics

# Microsoft Excel

### The first task in the Careerfoundry course was to analyze the game market for GameCo
### Objective

### Analyze how GameCo‘s new games might fare in the market
## Key Questions

   ### Are certain types of games more popular than others?
   ### What other publishers will likely be the main competitors in specific markets?
   ### Have any games decreased or increased in popularity over time?
   ### How have their sales figures varied between geographic regions over time?
